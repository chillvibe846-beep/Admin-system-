ONE-CLICK LAPTOP AUDIT

Admin PC: MASTER
Central folder: \\MASTER\IT-Asset-Management\Laptop Audit Reports

Keep these two files together:
1. START_LAPTOP_AUDIT.cmd
2. Laptop_Audit_FINAL_V3.ps1

On each laptop:
1. Connect to the same office network as MASTER.
2. Confirm \\MASTER\IT-Asset-Management opens.
3. Double-click START_LAPTOP_AUDIT.cmd.
4. Wait for AUDIT COMPLETED.

The launcher:
- Tests MASTER connectivity.
- Tests the central share.
- Runs the full laptop audit.
- Creates a folder named after the laptop.
- Uploads the newest CSV and TXT reports.

Password is NOT stored in the scripts.
Windows may require MASTER\ITAdmin authentication the first time a laptop connects.
Do not put the ITAdmin password into the CMD/PS1 file.
