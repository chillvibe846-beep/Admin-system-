@echo off
setlocal EnableExtensions
title Office Laptop - Automatic IT Audit

echo ============================================================
echo        OFFICE IT ASSET MANAGEMENT - LAPTOP AUDIT
echo ============================================================
echo Admin PC: MASTER
echo.

if not exist "%~dp0Laptop_Audit_FINAL_V3.ps1" (
    echo ERROR: Laptop_Audit_FINAL_V3.ps1 was not found.
    echo Put this CMD file and the PS1 file in the same folder.
    pause
    exit /b 1
)

ping -n 1 MASTER >nul 2>&1
if errorlevel 1 (
    echo ERROR: MASTER is not reachable.
    echo Check the office network connection.
    pause
    exit /b 2
)

if not exist "\\MASTER\IT-Asset-Management\" (
    echo ERROR: Cannot access the central share.
    echo Connect once to \\MASTER\IT-Asset-Management
    echo Username: MASTER\ITAdmin
    pause
    exit /b 3
)

echo [1/3] Running laptop audit...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Laptop_Audit_FINAL_V3.ps1"
if errorlevel 1 (
    echo ERROR: Laptop audit failed.
    pause
    exit /b 4
)

set "REPORTDIR=%USERPROFILE%\Desktop\Laptop_Audit_Reports"
set "DEST=\\MASTER\IT-Asset-Management\Laptop Audit Reports\%COMPUTERNAME%"

echo.
echo [2/3] Creating central laptop folder...
if not exist "%DEST%\" mkdir "%DEST%" >nul 2>&1

echo [3/3] Uploading latest CSV/TXT reports...

for /f "delims=" %%F in ('dir /b /a-d /o-d "%REPORTDIR%\*.csv" 2^>nul') do (
    copy /Y "%REPORTDIR%\%%F" "%DEST%\" >nul
    goto CSV_DONE
)
:CSV_DONE

for /f "delims=" %%F in ('dir /b /a-d /o-d "%REPORTDIR%\*.txt" 2^>nul') do (
    copy /Y "%REPORTDIR%\%%F" "%DEST%\" >nul
    goto TXT_DONE
)
:TXT_DONE

echo.
echo ============================================================
echo AUDIT COMPLETED
echo ============================================================
echo Laptop       : %COMPUTERNAME%
echo Central path : %DEST%
echo.
echo Report uploaded successfully.
echo ============================================================
pause
endlocal
